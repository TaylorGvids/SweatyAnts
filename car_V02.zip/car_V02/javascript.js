function validate(form) {
var x = document.forms["myForm"]["name"].value;
var y = document.forms["myForm"]["password1"].value;
var z = document.forms["myForm"]["email"].value;
var a = document.forms["myForm"]["state"].value;
var b = document.forms["myForm"]["username"].value;
var c = document.forms["myForm"]["password2"].value;
var d = document.forms["myForm"]["dob"].value;
var e = document.forms["myForm"]["terms"].value;

var submit = true;

if (x == null || x == "") {
nameError = "*Please enter your surname";
document.getElementById("name_error").innerHTML = nameError;
submit = false;

}

if   (y == null || y == "") {
pass1Error= "*Please enter a password";
document.getElementById("pass1_error").innerHTML = pass1Error;
submit = false;
}

if  (z == null || z == "") {
emailError = "*Please enter your email";
document.getElementById("email_error").innerHTML = emailError;
var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
re.test(email);

submit = false;
}

if  (a == null || a == "") {
stateError = "*Please select a state";
document.getElementById("state_error").innerHTML = stateError;
submit = false;
}

if  (b == null || b == "") {
usernameError = "*Please enter a username";
document.getElementById("username_error").innerHTML = usernameError;
submit = false;
}
if  (c != y) {
pass2Error = "*Passwords do not match";
document.getElementById("pass2_error").innerHTML = pass2Error;
submit = false;

}

if  (d == null || d == "") {
dobError= "*Please enter your date of birth";		
document.getElementById("dob_error").innerHTML = dobError;


submit = false;

}

if  (e.checked != false  ) {
termsError= "*You must agree with the terms to register";		
document.getElementById("terms_error").innerHTML = termsError;

submit = false;

}

else {
	 submit = true; 
	
}

		return submit; 	
	

}
// end register form errors

