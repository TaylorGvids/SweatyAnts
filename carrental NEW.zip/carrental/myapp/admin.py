from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .models import CompHistory, UsersHistory

@admin.register(CompHistory)
class RentalHistAdmin(ImportExportModelAdmin):
    pass

@admin.register(UsersHistory)
class UserHistAdmin(ImportExportModelAdmin):
    pass
	