from .models import CompHistory, UsersHistory
import django_filters

class HistoryFilter(django_filters.FilterSet):
	Pickup_Store_Name = django_filters.CharFilter(lookup_expr='icontains')
	Customer_Name = django_filters.CharFilter(lookup_expr='icontains')
	Car_MakeName = django_filters.CharFilter(lookup_expr='icontains')
	
	class Meta:
		model = CompHistory
		fields = ['order_ID', 'Pickup_Store_Name',  'Customer_ID', 'Customer_Name', 'Car_ID', 'Car_MakeName']	

class UserFilter(django_filters.FilterSet):
	Customer_Name = django_filters.CharFilter(lookup_expr='icontains')
	Car_MakeName = django_filters.CharFilter(lookup_expr='icontains')

	class Meta:
		model = UsersHistory
		fields = ['Order_ID', 'Customer_ID', 'Customer_Name', 'Car_ID', 'Car_MakeName', 'Car_Model']	