from django.db import models
from django.utils import timezone


class CompHistory(models.Model):
	STATES_SELECT = (
		('QLD', 'Queensland'),
		('NSW', 'New South Wales'),
		('SA', 'South Australia'),
		('VIC', 'Victoria'),
		('TAS', 'Tasmania'), 
	)
	order_ID = models.IntegerField()
	Order_CreateDate = models.DateField(default=timezone.now)
	Order_PickupDate = models.DateField(default=timezone.now)			
	Order_PickupStore = models.CharField(max_length=200)
	Pickup_Store_Name = models.CharField(max_length=200)
	Pickup_Store_Address = models.CharField(max_length=200)	
	Pickup_Store_Phone = models.CharField(max_length=200)	
	Pickup_Store_City = models.CharField(max_length=200)	
	Pickup_Store_State_Name = models.CharField(max_length=200, choices = STATES_SELECT)		
	Order_ReturnDate = models.DateField(default=timezone.now)	
	Order_ReturnStore=	models.CharField(max_length=200)	
	Return_Store_Name=	models.CharField(max_length=200)	
	Return_Store_Address=models.CharField(max_length=200)	
	Return_Store_Phone=	models.CharField(max_length=200)	
	Return_Store_City=	models.CharField(max_length=200)	
	Return_Store_State=	models.CharField(max_length=200, choices = STATES_SELECT)	
	Customer_ID=	models.IntegerField()
	Customer_Name=	models.CharField(max_length=200)
	Customer_Phone=	models.CharField(max_length=200)
	Customer_Addresss=models.CharField(max_length=200)	
	Customer_Birthday = models.DateField(default=timezone.now)
	Customer_Gender=	models.CharField(max_length=200)
	Car_ID=	models.IntegerField()
	Car_MakeName=	models.CharField(max_length=200)
	Car_Model=	models.CharField(max_length=200)	
	Car_Series=	models.CharField(max_length=200)
	Car_SeriesYear=	models.CharField(max_length=200)
	Car_PriceNew=	models.IntegerField()
	Car_EngineSize=	models.CharField(max_length=200)
	Car_FuelSystem=	models.CharField(max_length=200)
	Car_TankCapacity=	models.CharField(max_length=200)
	Car_Power=	models.CharField(max_length=200)
	Car_SeatingCapacity=models.CharField(max_length=200)
	Car_StandardTransmission=models.CharField(max_length=200)
	Car_BodyType=models.CharField(max_length=200)
	Car_Drive=	models.CharField(max_length=200)
	Car_Wheelbase=	models.CharField(max_length=200)

	def publish(self):
		self.Order_ReturnDate = timezone.now()
		self.save()

	def __str__(self):
		return self.order_ID
		
class UsersHistory(models.Model):
	STATES_SELECT = (
			('QLD', 'Queensland'),
			('NSW', 'New South Wales'),
			('SA', 'South Australia'),
			('VIC', 'Victoria'),
			('TAS', 'Tasmania'), 
	)
	Store_ID =  models.IntegerField()
	Store_Name =  models.CharField(max_length=200)
	Store_Address =  models.CharField(max_length=200)
	Store_Phone =  models.CharField(max_length=200)	
	Store_City =  models.CharField(max_length=200)
	Store_State_Name =  models.CharField(max_length=200, choices = STATES_SELECT)
	Order_ID =  models.CharField(max_length=200)
	Order_CreateDate =  models.DateField(default=timezone.now)
	Pickup_Or_Return =  models.CharField(max_length=200)
	Pickup_Or_Return_Date =  models.DateField(default=timezone.now)
	Customer_ID =  models.IntegerField()
	Customer_Name =  models.CharField(max_length=200)
	Customer_Phone =  models.CharField(max_length=200)	
	Customer_Addresss =  models.CharField(max_length=200)
	Customer_Birthday =  models.DateField(default=timezone.now)
	Customer_Occupation =  models.CharField(max_length=200)
	Customer_Gender =  models.CharField(max_length=200)
	Car_ID =  models.IntegerField()
	Car_MakeName =  models.CharField(max_length=200)
	Car_Model =  models.CharField(max_length=200)
	Car_Series =  models.CharField(max_length=200)
	Car_SeriesYear =  models.CharField(max_length=200)
	Car_EngineSize =  models.CharField(max_length=200)
	Car_FuelSystem =  models.CharField(max_length=200)
	Car_TankCapacity =  models.CharField(max_length=200)
	Car_SeatingCapacity =  models.CharField(max_length=200)
	Car_StandardTransmission =  models.CharField(max_length=200)
	Car_BodyType =  models.CharField(max_length=200)
	Car_Drive =  models.CharField(max_length=200)
	Car_Wheelbase =  models.CharField(max_length=200)

	
	def publish(self):
		self.Order_CreateDate = timezone.now()
		self.save()

