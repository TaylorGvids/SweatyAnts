# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from .models import CompHistory, UsersHistory
from django.utils import timezone
from .forms import CompHistoryForm
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from django.template import RequestContext
from django.shortcuts import render_to_response
from .filters import HistoryFilter, UserFilter

# Create your views here.
def history(request):
    history_list = CompHistory.objects.all().order_by('-Order_ReturnDate')
    history_filter = HistoryFilter(request.GET, queryset=history_list)
    return render(request, 'myapp/rentalhistory.html', {'filter': history_filter})	
		
def search_page(request):
	return render(request, 'myapp/search.html',  {})
		
def register(request):
	return render(request, 'myapp/register.html',  {})

def login(request):
	return render(request, 'myapp/login.html',  {})

def user(request):
    history_list = UsersHistory.objects.all().order_by('-Order_CreateDate')
    history_filter = UserFilter(request.GET, queryset=history_list)
    return render(request, 'myapp/user_history.html', {'filter': history_filter})	


def post_new(request):
	if request.method == "POST":
		form = CompHistoryForm(request.POST)
		if form.is_valid():
			post = form.save(commit=False)
			post.save()
			history_list = CompHistory.objects.all().order_by('-Order_ReturnDate')
			history_filter = HistoryFilter(request.GET, queryset=history_list)
			return render(request, 'myapp/rentalhistory.html', {'filter': history_filter})	
	else:
		form = CompHistoryForm()
	return render(request, 'myapp/history_edit.html', {'form': form})
	
def rental_detail(request, pk):
    post = CompHistory.objects.get(pk=pk) 
    return render(request, 'myapp/rental_detail.html', {'post': post})
	


	
def personal_history(request, Customer_ID):
	posts = UsersHistory.objects.filter(Customer_ID=Customer_ID).order_by('Order_CreateDate')
	return render(request, 'myapp/personal_history.html', {'posts': posts})

