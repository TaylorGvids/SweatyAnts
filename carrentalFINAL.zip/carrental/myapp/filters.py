from .models import CompHistory, UsersHistory
import django_filters

#Company Rental History filter - used in the "Search" section of the Company History Page to filter the database
class HistoryFilter(django_filters.FilterSet):
	Pickup_Store_Name = django_filters.CharFilter(lookup_expr='icontains')
	Customer_Name = django_filters.CharFilter(lookup_expr='icontains')
	Car_MakeName = django_filters.CharFilter(lookup_expr='icontains')
	
	class Meta:
		model = CompHistory
		fields = ['order_ID', 'Pickup_Store_Name',  'Customer_ID', 'Customer_Name', 'Car_ID', 'Car_MakeName']	

		
#User History filter - used in the "Search" section of the User History Page to filter the database
class UserFilter(django_filters.FilterSet):
	Customer_Name = django_filters.CharFilter(lookup_expr='icontains')
	Car_MakeName = django_filters.CharFilter(lookup_expr='icontains')

	class Meta:
		model = UsersHistory
		fields = ['Order_ID', 'Customer_ID', 'Customer_Name', 'Car_ID', 'Car_MakeName', 'Car_Model']	