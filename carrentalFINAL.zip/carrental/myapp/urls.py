from django.conf.urls import *
from . import views

urlpatterns = [
	url(r'^$', views.search_page, name='search_page'),
	url(r'^register$', views.register, name='register'),
	url(r'^login$', views.login, name='login'),
	url(r'new/$', views.post_new, name='post_new'),
	url(r'rental/(?P<pk>[0-9]+)/$', views.rental_detail, name='rental_detail'), #url for each rental detail page is based of PK=id
	url(r'^user$', views.user, name='user'),
	url(r'userhistory/(?P<Customer_ID>[0-9]+)/$', views.personal_history, name='personal_history'),#url for each customer detail page is based of customer id
	url(r'^history/$', views.history, name='history'),	 

	]