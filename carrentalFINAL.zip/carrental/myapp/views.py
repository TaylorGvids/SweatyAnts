# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from .models import CompHistory, UsersHistory 
from django.utils import timezone
from .forms import CompHistoryForm
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from django.template import RequestContext
from django.shortcuts import render_to_response
from .filters import HistoryFilter, UserFilter

# Views
def history(request): # Rental History Page 
    history_list = CompHistory.objects.all().order_by('-Order_ReturnDate')
    history_filter = HistoryFilter(request.GET, queryset=history_list) # filter based off user input in Search form 
    return render(request, 'myapp/rentalhistory.html', {'filter': history_filter})	
		
def search_page(request):# Search Page 
	return render(request, 'myapp/search.html',  {})
		
def register(request): # Register Page
	return render(request, 'myapp/register.html',  {})

def login(request): #Login Page
	return render(request, 'myapp/login.html',  {})

def user(request): # User History Page
    history_list = UsersHistory.objects.all().order_by('-Order_CreateDate')
    history_filter = UserFilter(request.GET, queryset=history_list) # filter based off user input in Search form 
    return render(request, 'myapp/user_history.html', {'filter': history_filter})	


def post_new(request): # New Rental Entry Page
	if request.method == "POST":
		form = CompHistoryForm(request.POST)
		if form.is_valid(): #if the form is valid, save new entry to CompHistory database and redirect user to Rental History Page showing their new entry at the top of the table
			post = form.save(commit=False)
			post.save()
			history_list = CompHistory.objects.all().order_by('-Order_ReturnDate')
			history_filter = HistoryFilter(request.GET, queryset=history_list)
			return render(request, 'myapp/rentalhistory.html', {'filter': history_filter})	
	else:
		form = CompHistoryForm() # if form is not valid (e.g not all input is filled in), re-present form with error message 
	return render(request, 'myapp/history_edit.html', {'form': form})
	
def rental_detail(request, pk): #Specific Details of a Rental Page
    post = CompHistory.objects.get(pk=pk) 
    return render(request, 'myapp/rental_detail.html', {'post': post})
	
	
def personal_history(request, Customer_ID): #Specific Details of a Customer Page
	posts = UsersHistory.objects.filter(Customer_ID=Customer_ID).order_by('Order_CreateDate')
	return render(request, 'myapp/personal_history.html', {'posts': posts})

