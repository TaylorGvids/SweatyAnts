from django import forms
from .models import CompHistory, UsersHistory
from simple_search import search_form_factory

class CompHistoryForm(forms.ModelForm):

    class Meta:
        model = CompHistory
        fields = ('order_ID', 'Order_CreateDate', 'Order_PickupDate', 'Order_PickupStore', 'Pickup_Store_Name', 'Pickup_Store_Address', 'Pickup_Store_Phone', 'Pickup_Store_City', 'Pickup_Store_State_Name' , 'Order_ReturnDate', 
		'Order_ReturnStore' , 'Return_Store_Name', 'Return_Store_Address', 'Return_Store_Phone', 'Return_Store_City', 'Return_Store_State', 'Customer_ID', 'Customer_Name', 'Customer_Phone', 'Customer_Addresss', 'Customer_Birthday', 'Customer_Gender', 
		'Car_ID', 'Car_MakeName','Car_Model', 'Car_Series', 'Car_SeriesYear', 'Car_PriceNew', 'Car_EngineSize', 'Car_FuelSystem', 'Car_TankCapacity', 'Car_Power', 'Car_SeatingCapacity', 'Car_StandardTransmission', 'Car_BodyType', 'Car_Drive', 'Car_Wheelbase' 	)
