# page/urls.py
from django.conf.urls import url
from page import views

urlpatterns = [
    url(r'^$', views.HomePageView.as_view()),
    url(r'^car1/$', views.Car1PageView.as_view()),
]
